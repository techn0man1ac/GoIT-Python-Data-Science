# List
print([i for i in range(10)])
print([pow(i, i) for i in range(10) if i % 2])

# Dict
print({i:pow(i, 2) for i in range(10)})

# Set
print({i for i in range(10)})