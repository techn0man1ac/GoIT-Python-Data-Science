values = [100, -3, 10, 0, -100, 33]

positive_number = list(filter(lambda elem: elem > 0, values))
print(positive_number)