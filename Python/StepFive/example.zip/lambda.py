def number_sum(x, y):
    return x + y

sum = lambda x, y: x + y

print(sum(2, 6))