with open('Python/StepFive/raw_data.bin', 'wb') as fh:
    fh.write(b'Hello world!')

