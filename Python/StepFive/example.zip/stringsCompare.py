string1 = "Hello World"
string2 = "hello World"

if string1.lower() == string2.lower():
    print("Рядки однакові")
else:
    print("Рядки різні")

