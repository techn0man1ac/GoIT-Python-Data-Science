# Dont use data
class LessThanZero:
    def __init__(self):
        self.text()

    def text(self):
        print("You launch LessThanZero class")

test = LessThanZero()